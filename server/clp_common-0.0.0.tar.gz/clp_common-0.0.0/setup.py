from setuptools import find_packages, setup

setup(
    name='clp_common',
    packages=find_packages(include=['clp_common']),
    version='0.0.0',
    description='Conciso Lernbaustein Python - Common Parts of Client and Server Application.',
    author='Philipp Kroll',
)
